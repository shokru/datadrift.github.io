library(tidyverse)
library(shiny)
library(shinydashboard)
library(DT)
library(plotly)
library(gapminder)
library(shinyjs)
library(shinyalert)
library(FNN)

load("songs.RData")
songs2 <- songs %>% 
    mutate(popularity = popularity / 100,
           duration = (duration - min(duration))/(max(duration)- min(duration)))

ui <- dashboardPage(
    dashboardHeader(title = "Song Recommendation"),              # Title of the dashboard
    dashboardSidebar( 
        selectizeInput("artist", h4("Artist"),                   # Artist selection
                       choices = songs %>% pull(artist) %>% unique(),
                       selected = c("Lady Gaga"), multiple = F
        ),
        uiOutput("select"),                                       # Song selection
        numericInput("nb_songs", "Number of recommendations", value = 10, min = 5, max = 20, step = 1),
        checkboxGroupInput("criteria", "Criteria for recommendation", 
                           choices = c("popularity", "duration", "danceability", "energy", "speechiness", "valence"),
                           selected = c("popularity", "duration", "danceability", "energy", "speechiness", "valence"))
    ),
    dashboardBody(
        fluidRow(
            tabBox(
                title = "Results", height = "870px", width = 12,
                tabPanel("List", DT::dataTableOutput("table")),
                tabPanel("Plot", plotlyOutput("plot"))
                
            )
        )
    )
)

server <- function(input, output){
    # NEW ELEMENTS BELOW
    choices_for_songs_list <- reactive({
        songs %>% 
            filter(artist == input$artist) %>% 
            pull(song_name)          # pull() extracts one particular variable from a dataframe
    }) 
    
    output$select <- renderUI(
        selectizeInput("song", "Song", 
                       choices = choices_for_songs_list(),
                       multiple = FALSE)
    )
    
    data <- reactive({                       # Creates the dynamic data
        songs %>%                            # Filter song
            filter(song_name %in% input$song)
    })
    
    filt <- reactive({
        target <- filter(songs2, song_name == input$song) 
        neighbors <- get.knnx(data = songs2 %>% select(all_of(input$criteria)),    # Data source: be careful with the columns!
                              query = target %>% select(all_of(input$criteria)),   # Target (with the right columns)
                              k = input$nb_songs)                                  # Nb of neighbors
        as.numeric(neighbors$nn.index)
    })
    
    output$table <- DT::renderDataTable({
        songs[filt(),] %>%
            select(c("song_name", "artist", input$criteria))
    })
    
    output$plot <- renderPlotly({
        knn_data <-  songs[union(filt(),(1:3200)*4),] %>%
            select(c("song_name", input$criteria)) %>%
            pivot_longer(-song_name, names_to = "attribute", values_to = "value")
        g <-  knn_data %>%
            ggplot(aes(x = attribute, y = value, label = song_name)) + geom_jitter(size = 0.5) +
            geom_jitter(data = knn_data %>% 
                            filter(song_name %in% (songs[filt(),] %>% pull(song_name))), color = "yellow", size = 2) +
            geom_jitter(data = knn_data %>% 
                            filter(song_name == filter(songs, song_name == input$song) %>% pull(song_name)), 
                        color = "red", size = 3) +
            facet_wrap(.~ attribute, scales = "free") + theme_bw()
        ggplotly(g, height = 560) 
    })
    
}

# Run the app ----
shinyApp(ui = ui, server = server)