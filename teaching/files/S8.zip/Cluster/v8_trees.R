library(tidyverse)
library(shiny)
library(shinydashboard)
library(DT)
library(gapminder)
library(shinyjs)
library(shinyalert)
library(rpart)
library(rpart.plot)

load("songs.RData")

ui <- dashboardPage(
    dashboardHeader(title = "Popularity Tree"),                  # Title of the dashboard
    dashboardSidebar( 
        sliderInput("length", h4("Song length (seconds)"),     # Song selection
                    min = 30, max = 600, value = c(30,600),
                    step = 5
        ),
        selectizeInput("color", h4("Cluster color"),
                       choices = c("Grays", "Greens", "Blues", "Browns", "Oranges", "Reds", "Purples"),
                       selected = "Blues", multiple = F)
    ),
    dashboardBody(
        # This is for 2 colors: header & sidebar
        tags$head(tags$style(HTML('
                                .skin-blue .main-header .navbar {
                                background-color: #f4b943;
                                }
                                .skin-blue .main-sidebar {
                                background-color: #CFC2A8;
                                }'))),
        fluidRow(
            box(htmlOutput("text"), width = 12), 
            box(htmlOutput("text2"), width = 6), box(htmlOutput("text3"), width = 6),
            plotOutput("plot")
        )
    )
)

server <- function(input, output){
    data <- reactive({                       # Creates the dynamic data
        songs %>%                            # Filter years & country
            filter(duration >= input$length[1],
                   duration <= input$length[2])
    })
    
    output$plot <- renderPlot({
        fit_songs <- rpart(popularity ~ .,    # Short formula!
                           data = data() %>% select(-song_name, -artist, -album),  # Remove unnecessary variables
                           method = "anova", # Method: regression "anova" vs classification "class"
                           cp = 0.0001, 
                           maxdepth = 3)
        rpart.plot(fit_songs, box.palette = input$color)
    })
    
    output$text <- renderText(paste("This app displays a decision tree that explains how songs are optimally clustered into groups of","<B> homogeneous popularity</B>."))
    output$text2 <- renderText(paste("<B>Criteria</B>","for the clustering process are shown in bold font. Songs that match the criteria go to the left cluster. Songs that don't go to the right cluster. In the initial tree, the sample is split according to","<B> loudness</B>.", "Loud songs go to the right cluster (& are slightly more popular)."))
    output$text3 <- renderText(paste("Clusters are shown in rounded rectangles.", "<B>Popularity</B>","is coded in blue (base case): darker clusters feature more popular songs. The first number in the rectangle is the", "<B>average popularity</B>", "of the cluster (out of 100). The second number is the", "<B>size</B>", "of the cluster, as % of the total sample."))
}

# Run the app ----
shinyApp(ui = ui, server = server)