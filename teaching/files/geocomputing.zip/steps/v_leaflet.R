library(tidyverse)
library(shiny)
library(shinydashboard)
library(DT)
library(sf)  
library(leaflet)
library(tmap)

data(World)                   # The first column is the 3 character name, just like in the olympics dataset
names(World)[1] <- "Country"  # Change the column name; indeed, it's Country in olympics.RData
load("olympics.RData")


ui <- dashboardPage(
    dashboardHeader(title = "Olympic Medals"),                   # Title of the dashboard
    dashboardSidebar( 
        sliderInput("years", h4("Years"),                        # Element 1: year selection
                    min = 1895, max = 2015, 
                    value = c(1895, 2015), step = 5, sep = ""),
        checkboxGroupInput("season", h4("Season"),               # Element 2: season selection
                           choices = list("Summer" = "Summer", 
                                          "Winter" = "Winter"),
                           selected = c("Summer", "Winter")),
        checkboxGroupInput("gender", h4("Gender"),               # Element 3: gender selection
                           choices = list("Women" = "Women", 
                                          "Men" = "Men"),
                           selected = c("Women", "Men"))
        ),
    
    dashboardBody(
        leafletOutput("plot", height = 450),
        DT::dataTableOutput("table_1")
    )
)

server <- function(input, output){
    data <- reactive({                # Creates the dynamic data
        olympics %>%                  # Filter years, seasons & gender
            filter(Year >= input$years[1], 
                   Year <= input$years[2],
                   Season %in% input$season,
                   Gender %in% input$gender) 
    })
    
    output$table_1 <- DT::renderDataTable({data()})
    
    ####### NEW ELEMENTS BELOW !!!!!
    output$plot <- renderLeaflet({
        data_map <- data() %>%
            group_by(Country) %>%
            count()                                                         # Counts nb instances, like n()
        data_map <- left_join(World %>% 
                                  select(Country, geometry), data_map) %>%  # Joining the geometry column
            filter(Country != "ATA")
        palet <- colorNumeric("Spectral",                                   # Palette
                          domain = data_map %>% pull(n)#,                   # Domain of labels: nb medals
        )
                
        labels <- sprintf(                                                  # Below we define the labels
            "<strong>%s</strong><br/>%g Medals",                            # Adding text to label
            data_map$Country,                                               # We show the country name...
            data_map$n                                                      # ... and the nb medals
        ) %>% lapply(htmltools::HTML)                                       # Embedded all into html language
                   
        data_map %>% 
            data.frame() %>%                                # Turn into dataframe (technical)
            sf::st_sf() %>%                                 # Format in sf
            st_transform("+init=epsg:4326") %>%             # Convert in particular coordinate reference 
            leaflet() %>%                                   # Call leaflet
            addPolygons(fillColor = ~palet(n),        # Create the map (colored polygons)
                        weight = 2,                         # Width of separation line
                        opacity = 1,                        # Opacity of separation line
                        color = "white",                    # Color of separation line
                        dashArray = "3",                    # Dash size of separation line
                        fillOpacity = 0.7,                  # Opacity of polygon colors
                        highlight = highlightOptions(       # 5 lines below control the cursor impact
                            weight = 2,                       # Width of line
                            color = "#CBCBCB",                # Color of line
                            dashArray = "",                   # No dash
                            fillOpacity = 0.7,                # Opacity
                            bringToFront = TRUE),
                        label = labels,                     # LABEL! Defined above!
                        labelOptions = labelOptions(        # Label options below...
                            style = list("font-weight" = "normal", padding = "3px 8px"),
                            textsize = "15px",
                            direction = "auto")
            ) %>%
            addLegend(pal = palet,                    # Legend: comes from palet colors defined above
                      values = ~n,                    # Values come from lifeExp variable
                      opacity = 0.7,                  # Opacity of legend
                      title = "Map Legend",           # Title of legend
                      position = "bottomright")       # Position of legend
    })
}

# Run the app ----
shinyApp(ui = ui, server = server)